You need to install mono and wine in order to run the program with no problem, here is how:

Open the Terminal window ( Ctrl+Alt+T ) then type this command: 
sudo apt-get install mono-complete libmono-microsoft* wine1.4
Press Enter and type your password and then press Enter again.
Press Yes to download and install these files, and Wait to finish the downloading process.

Now you can run "PSN PKG Decryptor & Extractor" v1.7 and above with no problem :)

*********************************************************************************************

Note:

Have a problem to install mono or wine? Open Terminal and Type this command:
sudo apt-get update
Press Enter and type your password and then press Enter again.
Then do the install steps again from the beginning.

If Eula appears when installing Wine Press the Tab button then Press Enter to accept it.

Others:

Want to unlock the locked folder or files? Open Terminal and Type this command:
cd /home/foldername/
sudo chown -R foldername *
note that "foldername" is an example name of your folder that have a locked files.

Want to be a rooted? Open the Terminal and Type this command:
sudo -s
Press Enter and type your password and then press Enter again.

*********************************************************************************************